import './Desktop1.css'

export default function Desktop1() {
  return (
    <div className="desktop-1">
      <div className="container-1">
        <div className="navigation-bar">
          <span className="portfolio">
          Portfolio .
          </span>
          <div className="frame-1">
            <span className="about-1">
            About
            </span>
            <span className="interests">
            Interests
            </span>
            <span className="experience">
            Experience
            </span>
            <span className="projects-1">
            Projects
            </span>
            <span className="lets-connect-1">
            Let&#39;s Connect
            </span>
          </div>
        </div>
        <div className="about">
          <div className="container-11">
            <div className="frame-4">
              <div className="im-vidya-janani">
              I’m Vidya Janani.
              </div>
              <div className="frame-2">
                <span className="fresher">
                FRESHER     /
                </span>
                <span className="java">
                JAVA      /
                </span>
                <span className="ui-ux-designing">
                UI/UX DESIGNING
                </span>
              </div>
              <div className="aspiring-software-developer-with-strong-java-skills-and-apassion-for-ui-ux-design-seeking-an-entry-level-position-to-apply-my-technical-expertise-and-innovative-approach-in-developing-intuitive-user-centric-applications-committed-to-contributing-to-innovative-projects-and-professional-growth">
              Aspiring software developer with strong Java skills and a passion for UI/UX design. Seeking an entry-level position to apply my technical expertise and innovative approach in developing intuitive, user-centric applications. Committed to contributing to innovative projects and professional growth.<br />
              
              </div>
              <div className="frame-3">
                <span className="explore-my-work">
                Explore My Work
                </span>
              </div>
            </div>
            <img className="container-8" src="assets/vectors/Container9_x2.svg" />
          </div>
          <div className="ellipse-1">
          </div>
        </div>
        <div className="line-1">
        </div>
        <div className="my-interests-1">
          <div className="frame-5">
            <p className="my-interests">
            <span className="my-interests-sub-0"></span><span></span>
            </p>
            <span className="aspiring-software-developer-with-strong-java-skills-and-apassion-for-ui-ux-design-seeking-an-entry-level-position-to-apply-my-technical-expertise-and-innovative-approach-in-developing-intuitive-user-centric-applications-committed-to-contributing-to-innovative-projects-and-professional-growth-1">
            Aspiring software developer with strong Java skills and a passion for UI/UX design. Seeking an entry-level position to apply my technical expertise and innovative approach in developing intuitive, user-centric applications. Committed to contributing to innovative projects and professional growth.<br />
            
            </span>
          </div>
          <div className="group-1">
            <div className="container-16">
              <div className="frame-7">
                <div className="frame-11">
                  <div className="coco-twocolors-cup">
                    <img className="vector-10" src="assets/vectors/Vector4_x2.svg" />
                    <img className="container-4" src="assets/vectors/Container5_x2.svg" />
                  </div>
                </div>
                <div className="frame-6">
                  <div className="java-1">
                  JAVA
                  </div>
                  <span className="as-apassionate-learner-ihoned-my-skills-through-geeksfor-geeks-iam-eager-to-apply-my-knowledge-to-eek-opportunities-that-challenge-me-to-excel-in-java-development">
                  As a passionate Learner, I honed my skills through GeeksforGeeks . I am eager to apply my knowledge to eek opportunities that challenge me to  excel in Java development.
                  </span>
                </div>
              </div>
              <div className="frame-8">
                <div className="coco-twocolors-heart">
                  <img className="container-3" src="assets/vectors/Container1_x2.svg" />
                </div>
                <div className="frame-61">
                  <span className="ui-ux-designing-1">
                  UI/UX Designing
                  </span>
                  <span className="iam-passionate-about-ui-ux-design-and-eager-to-create-intuitive-user-friendly-interfaces-that-enhance-the-overall-user-experience">
                  I am passionate about UI/UX design and eager to create intuitive, user-friendly interfaces that enhance the overall user experience.
                  </span>
                </div>
              </div>
            </div>
            <div className="container-6">
              <div className="frame-9">
                <div className="coco-twocolors-award">
                  <img className="container" src="assets/vectors/Container2_x2.svg" />
                </div>
                <div className="frame-62">
                  <span className="technology">
                  Technology
                  </span>
                  <span className="im-eager-and-passionate-about-learning-new-cutting-edge-technologies-always-excited-to-stay-updated-and-enhance-my-skills">
                  I&#39;m eager and passionate about learning new cutting-edge technologies, always excited to stay updated and enhance my skills.
                  </span>
                </div>
              </div>
              <div className="frame-10">
                <div className="coco-twocolors-reserve">
                  <img className="vector-15" src="assets/vectors/Vector8_x2.svg" />
                  <img className="container-13" src="assets/vectors/Container3_x2.svg" />
                </div>
                <div className="frame-63">
                  <div className="personal-development">
                  Personal Development
                  </div>
                  <span className="dedicated-to-personal-growth-iinvest-time-in-reading-online-courses-and-tech-podcasts-to-stay-ahead-in-the-industry">
                  Dedicated to personal growth, I invest time in reading, online courses, and tech podcasts to stay ahead in the industry.<br />
                  
                  </span>
                </div>
              </div>
            </div>
            <div className="container-5">
              <div className="frame-11">
                <div className="coco-twocolors-two-user">
                  <img className="vector-6" src="assets/vectors/Vector2_x2.svg" />
                  <img className="vector-7" src="assets/vectors/Vector6_x2.svg" />
                </div>
                <div className="frame-64">
                  <div className="problem-solving">
                  Problem-Solving
                  </div>
                  <span className="driven-by-afervent-appetite-for-challenges-ithrive-on-devising-innovative-solutions-that-push-boundaries-and-drive-progress">
                  Driven by a fervent appetite for challenges, I thrive on devising innovative solutions that push boundaries and drive progress.<br />
                  
                  </span>
                </div>
              </div>
              <div className="frame-12">
                <div className="coco-twocolors-user-scan">
                  <img className="container-2" src="assets/vectors/Container4_x2.svg" />
                </div>
                <div className="frame-65">
                  <span className="entrepreneurial-spirit">
                  Entrepreneurial Spirit
                  </span>
                  <span className="fueled-by-arelentless-passion-for-innovation-startups-and-entrepreneurship-iepitomize-ambition-creativity-and-tenacity-in-pioneering-ground-breaking-ventures">
                  Fueled by a relentless passion for innovation, startups, and entrepreneurship, I epitomize ambition, creativity, and tenacity in pioneering ground breaking ventures.
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="line-2">
        </div>
        <div className="my-experience">
          <div className="container-12">
            <div className="frame-66">
              <p className="my-experience-1">
              <span className="my-experience-1-sub-0"></span><span></span>
              </p>
              <span className="experience-is-more-than-just-alist-of-past-roles-its-ajourney-of-growth-learning-and-achievement-in-this-section-each-role-represents-astepping-stone-in-my-career-demonstrating-my-commitment-to-excellence-and-my-ability-to-thrive-in-dynamic-environments-explore-my-experiences-to-gain-insight-into-my-skills-expertise-and-the-value-ican-bring-to-your-team">
              Experience is more than just a list of past roles – it&#39;s a journey of growth, learning, and achievement. In this section. Each role represents a stepping stone in my career, demonstrating my commitment to excellence and my ability to thrive in dynamic environments. Explore my experiences to gain insight into my skills, expertise, and the value I can bring to your team.
              </span>
            </div>
            <div className="frame-13">
              <div className="container-7">
                <div className="container-15">
                  <div className="rectangle-2">
                  </div>
                  <p className="company-name-tarcin-robotics-llp-duration-2912202217012023">
                  <span className="company-name-tarcin-robotics-llp-duration-2912202217012023-sub-3"></span><span className="company-name-tarcin-robotics-llp-duration-2912202217012023-sub-0"></span><span className="company-name-tarcin-robotics-llp-duration-2912202217012023-sub-2"></span><span className="company-name-tarcin-robotics-llp-duration-2912202217012023-sub-3"></span><span></span>
                  </p>
                </div>
                <span className="during-my-inaugural-internship-idelved-into-the-realm-of-io-tan-experience-that-proved-both-enriching-and-engaging-exploring-fundamental-io-tcomponents-and-their-operational-mechanisms-igained-insights-into-optimal-working-environments-utilizing-the-tinker-cad-platform-ideveloped-proficiency-in-practical-application-moreover-ispearheaded-abluetooth-car-project-enhancing-astandard-vehicle-structure-with-remote-control-functionality-via-abluetooth-module-this-hands-on-project-not-only-reinforced-my-technical-skills-but-also-honed-my-problem-solving-abilities-and-teamwork-dynamics-through-collaboration-with-peers-and-mentors-inavigated-challenges-and-successfully-delivered-afunctional-prototype-solidifying-my-passion-for-io-tdevelopment-and-laying-astrong-foundation-for-future-endeavors-in-the-field-this-experience-ignited-apassion-for-technology-driven-innovation-and-equipped-me-with-the-skills-and-confidence-to-tackle-complex-challenges-in-the-ever-evolving-io-tlandscape">
                During my inaugural internship, I delved into the realm of IoT, an experience that proved both enriching and engaging. Exploring fundamental IoT components and their operational mechanisms, I gained insights into optimal working environments. Utilizing the TinkerCAD platform, I developed proficiency in practical application. Moreover, I spearheaded a Bluetooth car project, enhancing a standard vehicle structure with remote control functionality via a Bluetooth module. This hands-on project not only reinforced my technical skills but also honed my problem-solving abilities and teamwork dynamics. Through collaboration with peers and mentors, I navigated challenges and successfully delivered a functional prototype, solidifying my passion for IoT development and laying a strong foundation for future endeavors in the field.This experience ignited a passion for technology-driven innovation and equipped me with the skills and confidence to tackle complex challenges in the ever-evolving IoT landscape.
                </span>
              </div>
              <div className="rectangle-10">
              </div>
            </div>
          </div>
          <img className="rectangle-1" src="assets/vectors/Rectangle1_x2.svg" />
        </div>
        <div className="line-3">
        </div>
        <div className="projects">
          <div className="frame-14">
            <p className="my-projects">
            <span className="my-projects-sub-0"></span><span></span>
            </p>
            <span className="explore-acurated-selection-of-my-projects-each-showcasing-my-expertise-and-creativity-in-solving-real-world-problems-dive-into-the-details-to-discover-how-ileveraged-cutting-edge-technologies-and-collaborated-with-cross-functional-teams-to-deliver-impactful-solutions-that-exceed-expectations">
            Explore a curated selection of my  projects, each showcasing my expertise and creativity in solving real-world problems. Dive into the details to discover how I leveraged cutting-edge technologies and collaborated with cross-functional teams to deliver impactful solutions that exceed expectations.
            </span>
          </div>
          <div className="container-14">
            <div className="whats-app-image-20240529-at-8511">
            </div>
            <div className="frame-15">
              <p className="title-smart-waste-management-system-using-io-t">
              <span className="title-smart-waste-management-system-using-io-t-sub-12"></span><span></span>
              </p>
              <p className="description-discover-our-innovative-smart-waste-management-system-acutting-edge-solution-designed-to-revolutionize-waste-disposal-practices-using-servo-motors-soil-moisture-sensors-arduino-microcontrollers-and-ultrasonic-sensors-our-system-intelligently-segregates-waste-into-two-distinct-categories-wet-and-dry-by-precisely-detecting-moisture-levels-in-the-waste-and-employing-ultrasonic-sensors-for-distance-measurement-our-system-ensures-accurate-sorting-and-efficient-disposal-experience-the-future-of-sustainable-waste-management-with-our-user-friendly-and-environmentally-conscious-solution">
              <span className="description-discover-our-innovative-smart-waste-management-system-acutting-edge-solution-designed-to-revolutionize-waste-disposal-practices-using-servo-motors-soil-moisture-sensors-arduino-microcontrollers-and-ultrasonic-sensors-our-system-intelligently-segregates-waste-into-two-distinct-categories-wet-and-dry-by-precisely-detecting-moisture-levels-in-the-waste-and-employing-ultrasonic-sensors-for-distance-measurement-our-system-ensures-accurate-sorting-and-efficient-disposal-experience-the-future-of-sustainable-waste-management-with-our-user-friendly-and-environmentally-conscious-solution-sub-0"></span><span></span>
              </p>
            </div>
          </div>
        </div>
        <div className="line-4">
        </div>
        <div className="connect">
          <div className="container-18">
            <div className="frame-16">
              <p className="lets-connect">
              <span className="lets-connect-sub-0"></span><span></span>
              </p>
            </div>
            <div className="frame-18">
              <div className="rectangle-6">
              </div>
              <div className="rectangle-7">
              </div>
              <div className="rectangle-8">
              </div>
              <div className="container-10">
                <div className="frame-17">
                  <div className="frame">
                    <img className="vector-1" src="assets/vectors/Vector_x2.svg" />
                  </div>
                  <img className="vector-2" src="assets/vectors/Vector10_x2.svg" />
                  <img className="vector" src="assets/vectors/Vector1_x2.svg" />
                  <img className="vector-3" src="assets/vectors/Vector3_x2.svg" />
                </div>
                <div className="container-17">
                  <div className="container">
                  +91-9345541310
                  </div>
                  <div className="mail-me">
                  Mail Me
                  </div>
                  <div className="github-vidya-janani">
                  Github | Vidya Janani
                  </div>
                  <p className="linked-in-vidya-janani">
                  <span className="linked-in-vidya-janani-sub-9" href="https://www.linkedin.com/in/vidyajananiv"></span><span href="https://www.linkedin.com/in/vidyajananiv"></span>
                  </p>
                </div>
              </div>
              <img className="rectangle-5" src="assets/vectors/Rectangle5_x2.svg" />
            </div>
            <div className="container-9">
              <p className="designed-by-vidyajanani">
              <span className="designed-by-vidyajanani-sub-0"></span><span className="designed-by-vidyajanani-sub-1"></span><span></span>
              </p>
            </div>
          </div>
          <div className="frame-19">
          </div>
        </div>
      </div>
      <img className="rectangle-3" src="assets/vectors/Rectangle3_x2.svg" />
      <div className="rectangle-41">
      </div>
    </div>
  )
}